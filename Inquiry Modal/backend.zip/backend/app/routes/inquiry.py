"""Inquiry routes for the FastAPI application."""

from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models.inquiry import Inquiry
from app.schemas.inquiry import InquiryCreate, InquiryOut
from app.dependencies.auth import get_current_user
from app.models.user import User

router = APIRouter(prefix="/inquiries", tags=["Inquiries"])


def get_db():
    """Get a new DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/", response_model=InquiryOut)
def create_inquiry(
    inquiry: InquiryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a new inquiry."""
    new_inquiry = Inquiry(**inquiry.dict(), created_by=current_user.id)
    db.add(new_inquiry)
    db.commit()
    db.refresh(new_inquiry)
    return new_inquiry


@router.get("/", response_model=List[InquiryOut])
def get_all_inquiries(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get all inquiries based on role."""
    if current_user.role == "sales":
        return db.query(Inquiry).filter(Inquiry.created_by == current_user.id).all()
    return db.query(Inquiry).all()


@router.get("/{inquiry_id}", response_model=InquiryOut)
def get_inquiry_by_id(
    inquiry_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a single inquiry by ID."""
    inquiry = db.query(Inquiry).filter(Inquiry.id == inquiry_id).first()
    if not inquiry:
        raise HTTPException(status_code=404, detail="Inquiry not found")

    if current_user.role == "sales" and inquiry.created_by != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied: not your inquiry")

    return inquiry


@router.put("/{inquiry_id}", response_model=InquiryOut)
def update_inquiry(
    inquiry_id: int,
    updated: InquiryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update inquiry with field-level access based on user role."""
    inquiry = db.query(Inquiry).filter(Inquiry.id == inquiry_id).first()
    if not inquiry:
        raise HTTPException(status_code=404, detail="Inquiry not found")

    if current_user.role == "admin":
        for key, value in updated.dict().items():
            setattr(inquiry, key, value)

    elif current_user.role == "sales":
        if inquiry.created_by != current_user.id:
            raise HTTPException(status_code=403, detail="Access denied: not your inquiry")
        allowed_fields = [
            "inquiry_id", "inquiry_date", "today_date", "period", "sales",
            "buyer", "stock_id", "shape", "ct", "color", "clarity", "cut",
            "po", "sym", "lab", "report", "dis_ppc", "ppc", "amt", "type",
            "sale_team_status", "payment", "remark_request"
        ]
        for field in allowed_fields:
            if field in updated.dict(exclude_unset=True):
                setattr(inquiry, field, getattr(updated, field))

    elif current_user.role == "backend":
        allowed_fields = [
            "location", "backend_status", "time", "status_of_stone",
            "qc_remark", "stone_confirmation_remark", "entry_status", "location_remark"
        ]
        for field in allowed_fields:
            if field in updated.dict(exclude_unset=True):
                setattr(inquiry, field, getattr(updated, field))

    elif current_user.role == "account":
        raise HTTPException(status_code=403, detail="Account users cannot update inquiries")

    db.commit()
    db.refresh(inquiry)
    return inquiry


@router.delete("/{inquiry_id}")
def delete_inquiry(
    inquiry_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete an inquiry by ID (admin only)."""
    inquiry = db.query(Inquiry).filter(Inquiry.id == inquiry_id).first()
    if not inquiry:
        raise HTTPException(status_code=404, detail="Inquiry not found")

    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Only admin can delete inquiries")

    db.delete(inquiry)
    db.commit()
    return {"message": "Inquiry deleted successfully"}
