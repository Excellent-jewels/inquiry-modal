"""Main entry point for the FastAPI application."""

from fastapi import FastAPI
from app.routes import auth, inquiry
from app.database import Base, engine

app = FastAPI()

Base.metadata.create_all(bind=engine)

app.include_router(auth.router)
app.include_router(inquiry.router)
