"""Authentication routes for the FastAPI application."""


import random
from datetime import datetime, timedelta, timezone

from app.core.security import create_token, hash_password, verify_password
from app.database import SessionLocal
from app.models.password_reset import PasswordReset
from app.models.user import User
from app.schemas.user import UserCreate, UserLogin, UserOut
from fastapi import APIRouter, Depends, HTTPException
from jose import JWTError, jwt
from sqlalchemy.orm import Session

SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"

router = APIRouter(prefix="/auth", tags=["Auth"])

def get_db():
    """Get a new DB session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/register", response_model=UserOut)
def register(user: UserCreate, db: Session = Depends(get_db)):
    """Register a new user."""
    if db.query(User).filter(User.email == user.email).first():

        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = User(
        name=user.name,
        email=user.email,
        role=user.role,
        password=hash_password(user.password)
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@router.post("/login")
def login(user: UserLogin, db: Session = Depends(get_db)):
    """Login a user and return a JWT token."""
    db_user = db.query(User).filter(User.email == user.email).first()
    if not db_user or not verify_password(user.password, db_user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token({"user_id": db_user.id, "role": db_user.role})
    return {"access_token": token, "token_type": "bearer"}

@router.post("/send-otp")
def send_otp(email: str, db: Session = Depends(get_db)):
    # sourcery skip: aware-datetime-for-utc
    """Send OTP to user email (mocked print)."""
    otp = str(random.randint(100000, 999999))
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=5)

    # Remove existing OTPs
    db.query(PasswordReset).filter(PasswordReset.email == email).delete()

    db.add(PasswordReset(email=email, otp=otp, expires_at=expires_at))
    db.commit()

    print(f"OTP for {email} is {otp}")  # Replace with real email logic
    return {"message": "OTP sent to your email"}

@router.post("/verify-otp")
def verify_otp(email: str, otp: str, db: Session = Depends(get_db)):
    """Verify the OTP sent to the user."""
    record = db.query(PasswordReset).filter_by(email=email, otp=otp).first()
    if not record or record.expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    record.is_verified = True
    db.commit()

    # Return a short-lived token for password reset
    token = jwt.encode({"email": email}, SECRET_KEY, algorithm=ALGORITHM)
    return {"reset_token": token}

@router.post("/reset-password")
def reset_password(new_password: str, token: str, db: Session = Depends(get_db)):
    """Reset the user's password using the reset token."""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("email")
    except JWTError as exc:
        raise HTTPException(status_code=400, detail="Invalid or expired token") from exc

    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password = hash_password(new_password)
    db.commit()
    return {"message": "Password reset successful"}
